## Package Dependencies

- cuda 11.3
- dgl0.9.0-cu113
- dgllife

## Running experiments

The default dataset is ACM.  You need to change the corresponding parameters  to train and evaluate on other datasets.


Pretrain:

- python pre_train.py

Prompting and test:

- python run.py

Prompt  Evaluation:

- python best_mask_choose.py

Prompt Pruning and Retuning:

- python retrain.py